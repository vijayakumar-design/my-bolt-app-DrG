import React, { useState } from 'react';
import { Home, Stethoscope } from 'lucide-react';
import { PlayerScreen } from './components/PlayerScreen';

function App() {
  const [activeScreen, setActiveScreen] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState<{
    category: string;
    title: string;
  } | null>(null);

  const HomeScreen = () => (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="text-center">
        <div className="bg-white/25 backdrop-blur-lg rounded-3xl p-12 shadow-2xl border border-white/20">
          <div className="w-24 h-24 bg-white/40 rounded-full flex items-center justify-center mx-auto mb-6">
            <Stethoscope className="w-12 h-12 text-purple-800" />
          </div>
          <h1 className="text-6xl font-bold text-white mb-4">Dr.G</h1>
          <p className="text-xl text-white/90 mb-8">Master Your Auscultation Skills</p>
          <p className="text-white/80 max-w-md mx-auto">
            Enhance your clinical listening abilities with our comprehensive lung sound training platform
          </p>
        </div>
      </div>
    </div>
  );

  const LungSoundsScreen = () => (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-3xl font-bold text-white text-center mb-8">Lung Sound Categories</h2>
        <div className="grid gap-6">
          <div 
            className="bg-white/95 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            onClick={() => setSelectedCategory({ category: 'crackles', title: 'Crackles' })}
          >
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mr-4">
                <div className="w-6 h-6 bg-white rounded-sm"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Crackles</h3>
                <p className="text-gray-600">Fine or Coarse</p>
              </div>
            </div>
            <p className="text-gray-700 mb-4">
              High-pitched, brief crackling sounds heard during inspiration. Often associated with fluid in the alveoli or airways.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-sm text-purple-500 font-medium">12 Audio Examples</span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedCategory({ category: 'crackles', title: 'Crackles' });
                }}
                className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-4 py-2 rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300 shadow-lg"
              >
                Start Learning
              </button>
            </div>
          </div>

          <div 
            className="bg-white/95 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            onClick={() => setSelectedCategory({ category: 'wheeze', title: 'Wheeze' })}
          >
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mr-4">
                <div className="w-6 h-6 bg-white rounded-full"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Wheeze</h3>
                <p className="text-gray-600">High-pitched</p>
              </div>
            </div>
            <p className="text-gray-700 mb-4">
              Continuous, high-pitched musical sounds typically heard during expiration. Associated with airway narrowing.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-sm text-purple-500 font-medium">8 Audio Examples</span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedCategory({ category: 'wheeze', title: 'Wheeze' });
                }}
                className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-4 py-2 rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300 shadow-lg"
              >
                Start Learning
              </button>
            </div>
          </div>

          <div 
            className="bg-white/95 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            onClick={() => setSelectedCategory({ category: 'ronchi', title: 'Ronchi' })}
          >
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mr-4">
                <div className="w-6 h-6 bg-white rounded-lg"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Ronchi</h3>
                <p className="text-gray-600">Low-pitched</p>
              </div>
            </div>
            <p className="text-gray-700 mb-4">
              Continuous, low-pitched sounds with a snoring quality. Usually heard during expiration and associated with airway secretions.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-sm text-purple-500 font-medium">10 Audio Examples</span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedCategory({ category: 'ronchi', title: 'Ronchi' });
                }}
                className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-4 py-2 rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300 shadow-lg"
              >
                Start Learning
              </button>
            </div>
          </div>

          <div 
            className="bg-white/95 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
            onClick={() => setSelectedCategory({ category: 'normal', title: 'Normal' })}
          >
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mr-4">
                <div className="w-6 h-6 bg-white rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Normal</h3>
                <p className="text-gray-600">Clear breath sounds</p>
              </div>
            </div>
            <p className="text-gray-700 mb-4">
              Clear, soft breath sounds heard over healthy lung tissue. These are the baseline sounds that help distinguish abnormal findings.
            </p>
            <div className="flex justify-between items-center">
              <span className="text-sm text-purple-500 font-medium">15 Audio Examples</span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedCategory({ category: 'normal', title: 'Normal' });
                }}
                className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-4 py-2 rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300 shadow-lg"
              >
                Start Learning
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Show player screen when category is selected
  if (selectedCategory) {
    return (
      <PlayerScreen
        category={selectedCategory.category}
        categoryTitle={selectedCategory.title}
        onBack={() => setSelectedCategory(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-300 via-purple-400 to-indigo-500 flex flex-col">
      {/* Main Content */}
      {activeScreen === 'home' && <HomeScreen />}
      {activeScreen === 'lung-sounds' && <LungSoundsScreen />}
      
      {/* Bottom Navigation */}
      {!selectedCategory && (
        <div className="sticky bottom-0 p-4">
        <div className="max-w-sm mx-auto bg-white/25 backdrop-blur-lg rounded-3xl p-3 shadow-2xl border border-white/20">
          <div className="flex justify-around items-center">
            <button
              onClick={() => setActiveScreen('home')}
              className={`flex flex-col items-center p-3 rounded-xl transition-all duration-300 ${
                activeScreen === 'home'
                  ? 'bg-white/40 text-white shadow-lg'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Home className="w-6 h-6 mb-1" />
              <span className="text-xs font-medium">Home</span>
            </button>
            
            <button
              onClick={() => setActiveScreen('lung-sounds')}
              className={`flex flex-col items-center p-3 rounded-xl transition-all duration-300 ${
                activeScreen === 'lung-sounds'
                  ? 'bg-white/40 text-white shadow-lg'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Stethoscope className="w-6 h-6 mb-1" />
              <span className="text-xs font-medium">Lung Sounds</span>
            </button>
          </div>
        </div>
      </div>
      )}
    </div>
  );
}

export default App;