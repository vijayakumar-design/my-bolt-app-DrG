import React, { useState, useEffect } from 'react'
import { ArrowLeft, ArrowRight, SkipForward, RefreshCw, BookOpen, Award } from 'lucide-react'
import { AudioPlayer } from './AudioPlayer'
import { LearningProgress } from './LearningProgress'

interface PlayerScreenProps {
  category: string
  categoryTitle: string
  onBack: () => void
}

interface AudioFile {
  name: string
  id: string
}

// Mock audio data for demonstration
const mockAudioData: Record<string, AudioFile[]> = {
  crackles: [
    { name: 'fine_crackles_01.mp3', id: 'crackles-1' },
    { name: 'fine_crackles_02.mp3', id: 'crackles-2' },
    { name: 'coarse_crackles_01.mp3', id: 'crackles-3' },
    { name: 'coarse_crackles_02.mp3', id: 'crackles-4' },
    { name: 'bilateral_crackles.mp3', id: 'crackles-5' },
  ],
  wheeze: [
    { name: 'expiratory_wheeze_01.mp3', id: 'wheeze-1' },
    { name: 'expiratory_wheeze_02.mp3', id: 'wheeze-2' },
    { name: 'inspiratory_wheeze.mp3', id: 'wheeze-3' },
    { name: 'polyphonic_wheeze.mp3', id: 'wheeze-4' },
  ],
  ronchi: [
    { name: 'low_pitched_ronchi_01.mp3', id: 'ronchi-1' },
    { name: 'low_pitched_ronchi_02.mp3', id: 'ronchi-2' },
    { name: 'sonorous_ronchi.mp3', id: 'ronchi-3' },
    { name: 'sibilant_ronchi.mp3', id: 'ronchi-4' },
  ],
  normal: [
    { name: 'normal_vesicular_01.mp3', id: 'normal-1' },
    { name: 'normal_vesicular_02.mp3', id: 'normal-2' },
    { name: 'normal_bronchial.mp3', id: 'normal-3' },
    { name: 'normal_bronchovesicular.mp3', id: 'normal-4' },
  ]
}

export const PlayerScreen: React.FC<PlayerScreenProps> = ({
  category,
  categoryTitle,
  onBack
}) => {
  const [audioFiles, setAudioFiles] = useState<AudioFile[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [loading, setLoading] = useState(true)
  const [completed, setCompleted] = useState<boolean[]>([])
  const [score, setScore] = useState(0)
  const [autoPlay, setAutoPlay] = useState(false)

  useEffect(() => {
    loadAudioFiles()
  }, [category])

  const loadAudioFiles = async () => {
    setLoading(true)
    try {
      // Simulate loading delay
      await new Promise(resolve => setTimeout(resolve, 500))
      
      const files = mockAudioData[category] || []
      setAudioFiles(files)
      setCompleted(new Array(files.length).fill(false))
    } catch (error) {
      console.error('Error loading audio files:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleNext = () => {
    if (currentIndex < audioFiles.length - 1) {
      markAsCompleted(currentIndex)
      setCurrentIndex(currentIndex + 1)
    }
  }

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
    }
  }

  const markAsCompleted = (index: number) => {
    const newCompleted = [...completed]
    if (!newCompleted[index]) {
      newCompleted[index] = true
      setCompleted(newCompleted)
      setScore(score + 10)
    }
  }

  const handleAudioEnded = () => {
    markAsCompleted(currentIndex)
    if (autoPlay && currentIndex < audioFiles.length - 1) {
      setTimeout(() => {
        setCurrentIndex(currentIndex + 1)
      }, 1000)
    }
  }

  const resetProgress = () => {
    setCurrentIndex(0)
    setCompleted(new Array(audioFiles.length).fill(false))
    setScore(0)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-300 via-purple-400 to-indigo-500 flex items-center justify-center">
        <div className="bg-white/95 backdrop-blur-lg rounded-2xl p-8 shadow-xl">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p className="text-gray-700">Loading audio files...</p>
        </div>
      </div>
    )
  }

  if (audioFiles.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-300 via-purple-400 to-indigo-500 flex items-center justify-center p-4">
        <div className="bg-white/95 backdrop-blur-lg rounded-2xl p-8 shadow-xl text-center">
          <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">No Audio Files Found</h3>
          <p className="text-gray-600 mb-4">
            Audio files for '{category}' category are not available.
          </p>
          <button
            onClick={onBack}
            className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-2 rounded-xl hover:from-purple-600 hover:to-indigo-600 transition-all duration-300"
          >
            Go Back
          </button>
        </div>
      </div>
    )
  }

  const currentFile = audioFiles[currentIndex]
  // Use a placeholder audio URL for demo purposes
  const audioUrl = 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav'

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-300 via-purple-400 to-indigo-500 p-4">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={onBack}
            className="p-3 bg-white/25 backdrop-blur-lg rounded-full shadow-lg border border-white/20 hover:bg-white/30 transition-all duration-300"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <div className="text-center">
            <h1 className="text-2xl font-bold text-white">{categoryTitle}</h1>
            <p className="text-white/80 text-sm">Learning Session</p>
          </div>
          <button
            onClick={resetProgress}
            className="p-3 bg-white/25 backdrop-blur-lg rounded-full shadow-lg border border-white/20 hover:bg-white/30 transition-all duration-300"
          >
            <RefreshCw className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Progress Component */}
        <LearningProgress
          current={currentIndex + 1}
          total={audioFiles.length}
          completed={completed}
          score={score}
        />

        {/* Current Audio Info */}
        <div className="bg-white/95 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 mb-6">
          <div className="text-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">
              Sample {currentIndex + 1}
            </h2>
            <p className="text-sm text-gray-600">
              {currentFile.name.replace(/\.(mp3|wav|m4a)$/i, '')}
            </p>
          </div>

          {/* Auto-play Toggle */}
          <div className="flex items-center justify-center mb-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={autoPlay}
                onChange={(e) => setAutoPlay(e.target.checked)}
                className="rounded border-gray-300 text-purple-500 focus:ring-purple-500"
              />
              <span className="text-sm text-gray-700">Auto-play next</span>
            </label>
          </div>
        </div>

        {/* Audio Player */}
        <AudioPlayer
          src={audioUrl}
          onEnded={handleAudioEnded}
          autoPlay={false}
        />

        {/* Navigation Controls */}
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 ${
              currentIndex === 0
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-white/95 backdrop-blur-lg text-gray-700 hover:bg-white shadow-lg border border-white/20'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Previous</span>
          </button>

          <button
            onClick={handleNext}
            disabled={currentIndex === audioFiles.length - 1}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 ${
              currentIndex === audioFiles.length - 1
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white hover:from-purple-600 hover:to-indigo-600 shadow-lg'
            }`}
          >
            <span>Next</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Completion Message */}
        {completed.filter(Boolean).length === audioFiles.length && (
          <div className="mt-6 bg-gradient-to-r from-green-100 to-emerald-100 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-green-200">
            <div className="text-center">
              <Award className="w-12 h-12 text-green-600 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-green-800 mb-2">
                Congratulations! 🎉
              </h3>
              <p className="text-green-700 text-sm mb-4">
                You've completed all {audioFiles.length} samples in the {categoryTitle} category!
              </p>
              <div className="flex space-x-3 justify-center">
                <button
                  onClick={resetProgress}
                  className="px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors duration-300"
                >
                  Practice Again
                </button>
                <button
                  onClick={onBack}
                  className="px-4 py-2 bg-white text-green-600 border border-green-300 rounded-xl hover:bg-green-50 transition-colors duration-300"
                >
                  Choose New Category
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}