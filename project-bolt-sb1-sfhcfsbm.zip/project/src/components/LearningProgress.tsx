import React from 'react'
import { CheckCircle, Circle, Star, Trophy } from 'lucide-react'

interface LearningProgressProps {
  current: number
  total: number
  completed: boolean[]
  score?: number
}

export const LearningProgress: React.FC<LearningProgressProps> = ({
  current,
  total,
  completed,
  score = 0
}) => {
  const completedCount = completed.filter(Boolean).length
  const progressPercentage = (completedCount / total) * 100

  return (
    <div className="bg-white/95 backdrop-blur-lg rounded-2xl p-6 shadow-xl border border-white/20 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">Learning Progress</h3>
          <p className="text-sm text-gray-600">
            {current} of {total} • {completedCount} completed
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Star className="w-5 h-5 text-yellow-500" />
          <span className="font-semibold text-gray-800">{score}</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-purple-500 to-indigo-500 h-3 rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        <p className="text-xs text-gray-500 mt-1">{Math.round(progressPercentage)}% Complete</p>
      </div>

      {/* Achievement Badge */}
      {progressPercentage === 100 && (
        <div className="flex items-center justify-center p-3 bg-gradient-to-r from-yellow-100 to-orange-100 rounded-xl">
          <Trophy className="w-5 h-5 text-yellow-600 mr-2" />
          <span className="text-sm font-medium text-yellow-800">Category Mastered!</span>
        </div>
      )}

      {/* Mini Progress Dots */}
      <div className="flex flex-wrap gap-1 mt-4">
        {completed.map((isCompleted, index) => (
          <div
            key={index}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === current - 1
                ? 'bg-gradient-to-r from-purple-500 to-indigo-500 ring-2 ring-purple-300'
                : isCompleted
                ? 'bg-green-500'
                : 'bg-gray-300'
            }`}
          />
        ))}
      </div>
    </div>
  )
}